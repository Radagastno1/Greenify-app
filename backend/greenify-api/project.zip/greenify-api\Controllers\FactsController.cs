using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.IO;
using fileIO = System.IO.File;

[Route("api/facts")]
[ApiController]
public class FactsController : ControllerBase
{
    private readonly ILogger<FactsController> _logger;

    public FactsController(ILogger<FactsController> logger)
    {
        _logger = logger;
    }

    // GET: api/Facts
    [HttpGet]
    public async Task<ActionResult<Fact>> GetFacts()
    {
        try
        {
            string path = "facts.json";
            string jsonString = fileIO.ReadAllText(path);
            var facts = JsonConvert.DeserializeObject<List<Fact>>(jsonString);
            Random random = new();
            int randomNr = random.Next(1, facts.Count);
            Fact fact = new();

            try
            {
                fact = facts.Find(f => f.Id == randomNr);
            }
            catch (InvalidOperationException)
            {
                randomNr = random.Next(0, facts.Count);
            }
            return Ok(fact);
        }
        catch (Exception e)
        {
            _logger.LogError(e, "An error occurred while processing the request.");
            throw;
        }
    }

    [HttpGet("{material}")]
    public async Task<ActionResult<Fact>> GetByMaterial(string material)
    {
        try
        {
            string path = "facts.json";
            string jsonString = fileIO.ReadAllText(path);
            var facts = JsonConvert.DeserializeObject<List<Fact>>(jsonString);
            Fact fact = new();

            try
            {
                if (facts != null)
                {
                    fact = facts.Find(f => f.Material == material);
                }
            }
            catch (InvalidOperationException) { }
            return Ok(fact);
        }
        catch (Exception e)
        {
            return StatusCode(StatusCodes.Status500InternalServerError, e.Message);
        }
    }
}
