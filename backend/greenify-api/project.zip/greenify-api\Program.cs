using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;

class Program
{
    static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Lägg till MVC-tjänster
        builder.Services.AddControllers();

        var app = builder.Build();

        // Aktivera HTTPS-omdirigering (för säkerhet)
        app.UseHttpsRedirection();

        // Aktivera routing
        app.UseRouting();

        // Aktivera autentisering och auktorisering om du behöver det
        app.UseAuthorization();

        // Lägg till API-routes
        app.MapControllers();

        // Starta webbapplikationen
        app.Run();
    }
}
